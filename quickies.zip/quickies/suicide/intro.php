<tr>
  <td style="text-align:center;"><img alt="suicide quickies" src="../../images/standard/titles/suicideQuickies.png"/></td>
</tr>
<tr>
  <td>
	<br/>
	<p class="intro">
		Suicide Quickies are the most challenging level of <a href="http://www.calworkouts.com/quickies/">Quickies</a> that should not be taken lightly.  As a matter of fact, Cal rates ALL of these quickies at a FIVE or higher.. Yeah, we know the scale maxes out at five.  Suicide Quickies are not meant to kill you, but are designed to push the limits of athletes who are already at a high level of fitness.  It is highly recommended that you have completed the <a href="http://www.calworkouts.com/quickies/basic/">Basic Quickies</a> and <a href="http://www.calworkouts.com/quickies/cardio/">Cardio Quickies</a> Like A Boss prior to attempting these quickies.  If you have already performed the Basic and Cardio Quickies Like A BAMF, more power to you!  Despite the high level of difficulty of Suicide Quickies, like all quickies, these are intended to be completed in under 5 minutes.  Nonetheless, it is always preferred to have good form and take more time as opposed to finishing quickly with sloppy form.  If you can't do Suicide Quickies, don't worry about it, just continue with the other quickies and gradually progress forward by doing one of the many variations until you get there.  <span style="font-weight:bold;">Go Hard or Go Home!</span><br/><br/>  Note: DO NOT attempt Suicide Quickies unless you are a Cal Workouts certified B.A.M.F. (aka you have mastered all other quickies)
	</p><br/>
<?php
	include("../quickieTemplate/sortAndDisplay.php");
?>
  </td>
</tr>