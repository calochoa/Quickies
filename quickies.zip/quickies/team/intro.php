<tr>
  <td style="text-align:center;"><img alt="the quickies team" src="../../images/standard/titles/theQuickiesTeam.png"/></td>
</tr>
<tr>
  <td>
  <br/>
  <p class="intro">
	The Quickies Team originated in January 2011, where Cal, his brother JV, and his 
	buddy Day decided to do all the 2009 Quickies as a warm-up before lifting weights 
	at the gym.  After realizing it was such a great workout, Cal decided to invent 
	more Quickies to make it a complete and awesome workout.  With the addition of 
	more people, this later evolved into an activity that is still continuing up to 
	this very day.  Every Sunday at 9:30am, the Quickies Team meets up at the Santa 
	Clara High School track to perform all the Quickies or some variation of them.  
	And now with <a href="http://www.calworkouts.com/quickies/beta/">Beta Quickies</a> 
	added in the mix, the Quickies Team has the responsibility of testing and critiquing 
	future <a href="http://www.calworkouts.com/quickies">Cal Approved Quickies</a> or 
	potential <a href="http://www.calworkouts.com/quickies/reject/">Reject Quickies</a>.  
	In the end, the Quickies Team ALWAYS GOES HARD!
	<br/><br/>
	Note: Anyone is welcome to work out with the Quickies Team on Sundays, but to 
	make the official team requires a little bit more.  Hence, the "Provisional 
	Quickies Team Members" at the bottom of the page.  Go Hard or Go Home!
	<br/><br/>
  </p>
  </td>
</tr>