<div id="quickieHistory<?php echo $templateQuickieId; ?>" style="display:none; line-height:125%;">
	<table border="0" style="font-size:13px; width:100%;">
		<tr>
			<td style="padding-left:20px; padding-right:20px;">
				<?php echo $templateQuickieHistory; ?>
			</td>
		</tr>
	</table>
</div>