<tr>
  <td style="text-align:center;"><img alt="reject quickies" src="../../images/standard/titles/rejectQuickies.png"/></td>
</tr>
<tr>
  <td>
  <br/>
  <p class="intro">
	Reject Quickies are <a href="http://www.calworkouts.com/quickies/beta/">Beta Quickies</a>
	that were reviewed and tested by the <a href="http://www.calworkouts.com/quickies/team/">
	Quickies Team</a> and for some reason did not make the cut.  They may have been too difficult, 
	too easy, not practical, too long, too short, not unique, or just plain wrong.  Whatever the 
	case may be, these Reject Quickies will forever be on this list for others to point and laugh
	at or perhaps just to remind people of what Quickies should not be.<br/><br/>
  </p>
  </td>
</tr>