<tr>
  <td>
  <br/>
  <div class="tableBorder">
  <div class="tableTitle">Too Easy</div>
  <table border="0" width="100%">
  <tr>
	<td align="left" valign="top" colspan="4">
	  <p class="newTop"><b>UPPER BODY</b></p>
	</td>
  </tr>
  <tr>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Basic</b>
	  <?php 
		echo popUpLink("10", "pullUp", "pull-ups");
	  	echo popUpLink("20", "pushUp", "push-ups");
	  	echo popUpLink("30", "dip", "dips");
	  	echo popUpLink("20", "pushUp", "push-up");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Like a Boss</b>
	  <?php 
		echo popUpLink("20", "pullUp", "pull-ups");
	  	echo popUpLink("40", "pushUp", "push-ups");
	  	echo popUpLink("60", "dip", "dips");
	  	echo popUpLink("40", "pushUp", "push-up");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Like a BAMF</b>
	  <?php 
		echo popUpLink("40", "pullUp", "pull-ups");
	  	echo popUpLink("80", "pushUp", "push-ups");
	  	echo popUpLink("120", "dip", "dips");
	  	echo popUpLink("80", "pushUp", "push-up");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Advanced:</b> Ladder Style (ex: ladder 7)
	  <?php 
		echo popUpLink("7", "pullUp", "pull-ups").popUpLink(", 7", "pushUp", "push-ups").popUpLink(", 7", "dip", "dips").popUpLink(", 7", "pushUp", "push-ups");
		echo popUpLink("6", "pullUp", "pull-ups").popUpLink(", 6", "pushUp", "push-ups").popUpLink(", 6", "dip", "dips").popUpLink(", 6", "pushUp", "push-ups");
		echo "<br/><b>. . .</b>";
		echo popUpLink("1", "pullUp", "pull-up").popUpLink(", 1", "pushUp", "push-up").popUpLink(", 1", "dip", "dip").popUpLink(", 1", "pushUp", "push-up");
	  ?>
	  </p>
	</td>
  </tr>
  </table>
  </div><!--end border-->
  </td>
</tr>