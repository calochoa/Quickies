<tr>
  <td>
  <br/>
  <div class="tableBorder">
  <div class="tableTitle">Bang Bang Boogie</div>
  <table border="0" width="100%">
  <tr>
	<td align="left" valign="top" colspan="4">
	  <p class="newTop"><b>TOTAL BODY</b> (Note: h. = heiden, mtn. = mountain)</p>
	</td>
  </tr>
  <tr>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Basic</b>
	  <?php 
		echo popUpLink("10", "heidenHop", "h. hops");
	  	echo popUpLink("20", "kneeStrike", "knee strikes");
	  	echo popUpLink("20", "mountainClimber", "mtn. climbers");
	  	echo popUpLink("10", "burpee", "burpees");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Like a Boss</b>
	  <?php 
		echo popUpLink("20", "heidenHop", "h. hops");
	  	echo popUpLink("40", "kneeStrike", "knee strikes");
	  	echo popUpLink("40", "mountainClimber", "mtn. climbers");
	  	echo popUpLink("20", "burpee", "burpees");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Like a BAMF</b>
	  <?php 
		echo popUpLink("40", "heidenHop", "h. hops");
	  	echo popUpLink("80", "kneeStrike", "knee strikes");
	  	echo popUpLink("80", "mountainClimber", "mtn. climbers");
	  	echo popUpLink("40", "burpee", "burpees");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Advanced:</b> Ladder Style (ex: ladder 7)
	  <?php 
		echo popUpLink("7", "heidenHop", "h. hops").popUpLink(", 7", "kneeStrike", "knee strikes").popUpLink(", 7", "mountainClimber", "mtn. climbers").popUpLink(", 7", "burpee", "burpees");
		echo popUpLink("6", "heidenHop", "h. hops").popUpLink(", 6", "kneeStrike", "knee strikes").popUpLink(", 6", "mountainClimber", "mtn. climbers").popUpLink(", 6", "burpee", "burpees");
		echo "<br/><b>. . .</b>";
		echo popUpLink("1", "heidenHop", "h. hop").popUpLink(", 1", "kneeStrike", "knee strike").popUpLink(", 1", "mountainClimber", "mtn. climber").popUpLink(", 1", "burpee", "burpee");
	  ?>
	  </p>
	</td>
  </tr>
  </table>
  </div><!--end border-->
  </td>
</tr>