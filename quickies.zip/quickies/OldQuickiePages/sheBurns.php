<tr>
  <td>
  <br/>
  <div class="tableBorder">
  <div class="tableTitle">She Burns</div>
  <table border="0" width="100%">
  <tr>
	<td align="left" valign="top" colspan="4">
	  <p class="newTop"><b>LOWER BODY</b> (Note: s.s. = shooting for the stars)</p>
	</td>
  </tr>
  <tr>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Basic</b>
	  <?php 
		echo popUpLink("10", "shootingForTheStars", "s.s.");
	  	echo popUpLink("20", "boxSquat", "box squats");
	  	echo popUpLink("30", "lunge", "lunges");
	  	echo popUpLink("40", "calfRaise", "calf-raises");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Like a Boss</b>
	  <?php 
		echo popUpLink("20", "shootingForTheStars", "s.s.");
	  	echo popUpLink("40", "boxSquat", "box squats");
	  	echo popUpLink("60", "lunge", "lunges");
	  	echo popUpLink("80", "calfRaise", "calf-raises");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Like a BAMF</b>
	  <?php 
		echo popUpLink("40", "shootingForTheStars", "s.s.");
	  	echo popUpLink("80", "boxSquat", "box squats");
	  	echo popUpLink("120", "lunge", "lunges");
	  	echo popUpLink("160", "calfRaise", "calf-raises");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Advanced:</b> Ladder Style (ex: ladder 7)
	  <?php 
		echo popUpLink("7", "shootingForTheStars", "s.s.").popUpLink(", 7", "boxSquat", "box squats").popUpLink(", 7", "lunge", "lunges").popUpLink(", 7", "calfRaise", "calf-raises");
		echo popUpLink("6", "shootingForTheStars", "s.s.").popUpLink(", 6", "boxSquat", "box squats").popUpLink(", 6", "lunge", "lunges").popUpLink(", 6", "calfRaise", "calf-raises");
		echo "<br/><b>. . .</b>";
		echo popUpLink("1", "shootingForTheStars", "s.s.").popUpLink(", 1", "boxSquat", "box squat").popUpLink(", 1", "lunge", "lunge").popUpLink(", 1", "calfRaise", "calf-raise");
	  ?>
	  </p>
	</td>
  </tr>
  </table>
  </div><!--end border-->
  </td>
</tr>