<tr>
  <td>
  <br/>
  <div class="tableBorder">
  <div class="tableTitle">Hip-Hop You Don't Stop</div>
  <table border="0" width="100%">
  <tr>
	<td align="left" valign="top" colspan="4">
	  <p class="newTop"><b>LOWER BODY</b> (Note: h. = heiden, f.b. = forward backward, s.s. = side-to-side, c.w. = clockwise, c.c.w. = counterclockwise)</p>
	</td>
  </tr>
  <tr>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Basic</b>
	  <?php 
		echo popUpLink("10", "heidenHop", "h. hops");
	  	echo popUpLink("10", "fwdBwdHop", "f.b. hops");
	  	echo popUpLink("10", "sideToSideHop", "s.s. hops");
	  	echo popUpLink("5", "clockwiseHop", "c.w. hops");
		echo popUpLink("5", "counterclockwiseHop", "c.c.w. hops");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Like a Boss</b>
	  <?php 
		echo popUpLink("20", "heidenHop", "h. hops");
	  	echo popUpLink("20", "fwdBwdHop", "f.b. hops");
	  	echo popUpLink("20", "sideToSideHop", "s.s. hops");
	  	echo popUpLink("10", "clockwiseHop", "c.w. hops");
		echo popUpLink("10", "counterclockwiseHop", "c.c.w. hops");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Like a BAMF</b>
	  <?php 
		echo popUpLink("40", "heidenHop", "h. hops");
	  	echo popUpLink("40", "fwdBwdHop", "f.b. hops");
	  	echo popUpLink("40", "sideToSideHop", "s.s. hops");
	  	echo popUpLink("20", "clockwiseHop", "c.w. hops");
		echo popUpLink("20", "counterclockwiseHop", "c.c.w. hops");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Advanced:</b> Ladder Style (ex: ladder 7)
	  <?php 
		echo popUpLink("7", "heidenHop", "h. hops").popUpLink(", 7", "fwdBwdHop", "f.b. hops").popUpLink(", 7", "sideToSideHop", "s.s. hops").popUpLink(", 7", "clockwiseHop", "c.w. hops").popUpLink(", 7", "counterclockwiseHop", "c.c.w. hops");
		echo popUpLink("6", "heidenHop", "h. hops").popUpLink(", 6", "fwdBwdHop", "f.b. hops").popUpLink(", 6", "sideToSideHop", "s.s. hops").popUpLink(", 6", "clockwiseHop", "c.w. hops").popUpLink(", 6", "counterclockwiseHop", "c.c.w. hops");
		echo "<br/><b>. . .</b>";
		echo popUpLink("2", "heidenHop", "h. hops").popUpLink(", 2", "fwdBwdHop", "f.b. hops").popUpLink(", 2", "sideToSideHop", "s.s. hops").popUpLink(", 2", "clockwiseHop", "c.w. hops").popUpLink(", 2", "counterclockwiseHop", "c.c.w. hops");
		echo popUpLink("1", "heidenHop", "h. hop").popUpLink(", 1", "fwdBwdHop", "f.b. hop").popUpLink(", 1", "sideToSideHop", "s.s. hop").popUpLink(", 1", "clockwiseHop", "c.w. hop").popUpLink(", 1", "counterclockwiseHop", "c.c.w. hop");
	  ?>
	  </p>
	</td>
  </tr>
  </table>
  </div><!--end border-->
  </td>
</tr>