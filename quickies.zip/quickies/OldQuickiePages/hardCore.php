<tr>
  <td>
  <br/>
  <div class="tableBorder">
  <div class="tableTitle">Hardcore</div>
  <table border="0" width="100%">
  <tr>
	<td align="left" valign="top" colspan="4">
	  <p class="newTop"><b>CORE</b> (Note: f.b.c. = full-body crunches, bi. = bicycle)</p>
	</td>
  </tr>
  <tr>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Basic</b>
	  <?php 
		echo popUpLink("25", "chestUp", "chest-ups");
	  	echo popUpLink("25", "legRaise", "leg raises");
	  	echo popUpLink("25", "bicycleCrunch", "bi. crunches");
	  	echo popUpLink("25", "fullBodyCrunch", "f.b.c.");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Like a Boss</b>
	  <?php 
		echo popUpLink("50", "chestUp", "chest-ups");
	  	echo popUpLink("50", "legRaise", "leg raises");
	  	echo popUpLink("50", "bicycleCrunch", "bi. crunches");
	  	echo popUpLink("50", "fullBodyCrunch", "f.b.c.");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Like a BAMF</b>
	  <?php 
		echo popUpLink("100", "chestUp", "chest-ups");
	  	echo popUpLink("100", "legRaise", "leg raises");
	  	echo popUpLink("100", "bicycleCrunch", "bi. crunches");
	  	echo popUpLink("100", "fullBodyCrunch", "f.b.c.");
	  ?>
	  </p>
	</td>
	<td align="left" valign="top">
	  <p class="newBot">
	  <b>Advanced:</b> Ladder Style (ex: ladder 7)
	  <?php 
		echo popUpLink("7", "chestUp", "chest-ups").popUpLink(", 7", "legRaise", "leg raises").popUpLink(", 7", "bicycleCrunch", "bi. crunches").popUpLink(", 7", "fullBodyCrunch", "f.b.c.");
		echo popUpLink("6", "chestUp", "chest-ups").popUpLink(", 6", "legRaise", "leg raises").popUpLink(", 6", "bicycleCrunch", "bi. crunches").popUpLink(", 6", "fullBodyCrunch", "f.b.c.");
		echo "<br/><b>. . .</b>";
		echo popUpLink("1", "chestUp", "chest-up").popUpLink(", 1", "legRaise", "leg raise").popUpLink(", 1", "bicycleCrunch", "bi. crunch").popUpLink(", 1", "fullBodyCrunch", "f.b.c.");
	  ?>
	  </p>
	</td>
  </tr>
  </table>
  </div><!--end border-->
  </td>
</tr>