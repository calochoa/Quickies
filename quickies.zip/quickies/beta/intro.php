<tr>
  <td style="text-align:center;"><img alt="beta quickies" src="../../images/standard/titles/betaQuickies.png"/></td>
</tr>
<tr>
  <td>
  <br/>
  <p class="intro">
	Beta Quickies are an opportunity for anyone to come up with there own Quickie with the potential to 
	become an <a href="http://www.calworkouts.com/quickies/">official Quickie</a>.  The minimum requirements 
	to create a Quickie is that it must consist of 4 different exercises and can be performed in under 5 
	minutes by at least the person creating it.  All Beta Quickies will be reviewed and tested by the 
	<a href="http://www.calworkouts.com/quickies/team">Quickies Team</a>.  After careful examination and 
	possible modification of exercises, repetitions, and/or name, Beta Quickies will become one of four things: 
	a <a href="http://www.calworkouts.com/quickies/junior/">Junior Quickie</a>, 
	a <a href="http://www.calworkouts.com/quickies/basic/">Basic Quickie</a>, 
	a <a href="http://www.calworkouts.com/quickies/suicide/">Suicide Quickie</a>, or the infamous 
	<a href="http://www.calworkouts.com/quickies/reject/">Reject Quickie</a>.  With that in mind, remember 
	that Quickies are designed as a high intensity and short duration workout.  Do your best in designing 
	your Quickie as you do not want to end up on the reject list.
	<span style="font-weight:bold;">Go Hard or Go Home!</span><br/><br/>
	Note: There is no definite timeframe for which Beta Quickies will be approved or rejected.  
	The examination process takes time and a lot of factors must be taken into consideration.
	<br/><br/>
  </p>
  </td>
</tr>