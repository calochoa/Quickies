<tr>
  <td style="text-align:center;"><img alt="quickies awards" src="../../images/standard/titles/quickiesAwards.png"/></td>
</tr>
<tr>
  <td>
  <br/>
  <p class="intro">
	We bestow the following Quickies Awards each year to honor the best members of the <a href="http://www.calworkouts.com/quickies/team/">Quickies Team</a>:
  </p>
  	<table style="margin-left:30px;font-size: 13px; color: #505050; line-height: 1.4; text-align: left;">
		<tr>
			<td style="font-weight:bold;">Most Valuable Player:</td>
			<td>I carried the team!</td>
		</tr>
		<tr>
			<td style="font-weight:bold;">Rookie of the Year:</td>
			<td>I'm sexy and I know it!</td>
		</tr>
		<tr>
			<td style="font-weight:bold;">Most Improved:</td>
			<td>I went from beginner to Badass!</td>
		</tr>
		<tr>
			<td style="font-weight:bold;">Honorable Mention:</td>
			<td>I always go Hard!</td>
		</tr>
	</table>
	<br/>
  </td>
</tr>