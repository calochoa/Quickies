<tr>
	<td>
		<table border="1" width="100%" style="text-align:center; font-size:12px;">
			<tr style="color:white; background-color:#1F497D;">
				<td width="8%">Year</td>
				<td width="23%">Most Valuable Player</td>
				<td width="23%">Rookie of the Year</td>
				<td width="23%">Most Improved</td>
				<td width="23%">Honorable Mention</td>
			</tr>
			<tr bgcolor="#D0D0D0">
				<td>2011</td>
				<td><a class="memberNameCMM" href="http://www.calworkouts.com/members/profiles/admin.php">Cal Ochoa</a></td>
				<td><a class="memberNameCMM" href="http://www.calworkouts.com/members/profiles/edosugiq.php">J.V. Ochoa</a></td>
				<td><a class="memberNameCMM" href="http://www.calworkouts.com/members/profiles/imiperol.php">Day Riguera</a></td>
				<td><a class="memberNameCMM" href="http://www.calworkouts.com/members/profiles/go5upi6i.php">Frank Morales</a></td>
			</tr>
			<tr bgcolor="#FFFFFF">
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr bgcolor="#D0D0D0">
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr bgcolor="#FFFFFF">
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr bgcolor="#D0D0D0">
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr bgcolor="#FFFFFF">
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr bgcolor="#D0D0D0">
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr bgcolor="#FFFFFF">
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr bgcolor="#D0D0D0">
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr bgcolor="#FFFFFF">
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
		</table>
	</td>
</tr>