<tr>
  <td style="text-align:center;"><img alt="junior quickies" src="../../images/standard/titles/juniorQuickies.png"/></td>
</tr>
<tr>
  <td>
	<br/>
	<p class="intro">
		Junior Quickies are the easiest of all the <a href="http://www.calworkouts.com/quickies/">Quickies</a>.  If you are just starting to work out or are brand new to quickies, it is highly recommended that you start off with these.  These are definitely a good indicator of what kind of shape you are in.  For some people, these quickies may be quite challenging, and for others, it may be a piece of cake.  Remember that all quickies should be completed in under 5 minutes.  If this cannot be achieved, you should consider lowering the repetitions and progressively increase until you get there.  On the other hand, if you can finish in under 2 minutes with solid form, you are probably in good enough of shape to move on to <a href="http://www.calworkouts.com/quickies/basic/">Basic Quickies</a> or <a href="http://www.calworkouts.com/quickies/cardio/">Cardio Quickies</a>.  However, it is suggested that you at least attempt these quickies Like A Boss or Like A BAMF (refer to the variations tab) before proceeding to one of the other types of quickies.  Always remember to focus on technique while doing quickies in order to gain the most benefits.  Never sacrifice your form to finish faster because you'll only cheat yourself and regret it when you move on to the more challenging quickies.  <span style="font-weight:bold;">Go Hard or Go Home!</span><br/><br/>
	</p><br/>
<?php
	include("../quickieTemplate/sortAndDisplay.php");
?>
  </td>
</tr>